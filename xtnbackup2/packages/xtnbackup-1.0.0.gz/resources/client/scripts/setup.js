SetupPane Added to configure group
// - connect
// - workflow
// - dashboards
// - addresss validation
// - T&E

// create ui file
// fields reasonable names
// each script that backups setup panes loads values from db on startup and have actions on startup();
// setup script addsyour stuff to the setup window
// and a backupManagerSetup scrupt
  // reads metrics into fields
  // save metrics on save
  // backupManagerSetup UI Form
  // 2 script and 1 form
  // setmetric()

// Right Click Option
//  xtree widget - populateMenu
_list("populateMenu"(QMenu *, XTreeWidgetItem *)").connect(aPopulateMenu);

// right click on the display
aPopulateMenu = A function to do the applicationCache.
